For the game assets in Freebies section, 
it's under Creative Common Zero (CC0) a.k.a Public Domain license.

So, basically you can:
Use it on your commercial or non-commercial projects, 
whether it's an end product, templates, course materials, or whatever you name it.

Unlimited usage, there's no hidden cost & royalties.?
?Not necessary to put my name or this site link. But I won't stop you if you do that. :p
- See more at: http://www.gameart2d.com/license.html#sthash.H1UowjZp.dpuf

http://www.gameart2d.com/freebies.html

Copyright 2016 GameArt2D.com ALL RIGHTS RESERVED