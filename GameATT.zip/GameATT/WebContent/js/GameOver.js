/**
 *
 */
function GameOver () {
	Phaser.State.call(this);
	
}
/** @type Phaser.State */

var proto = Object.create(Phaser.State);
Story.prototype = proto;

GameOver.prototype.preload = function() {
	this.load.pack("start", "assets/assets-pack.json");
};

GameOver.prototype.create = function() {
	
	this.background = this.game.add.sprite(0,0,"gameover");
	this.background.height = 576;
	this.background.width = 1280;
	
	var twn = this.add.tween("gameover");
	twn.to({x :-50, y:0}, 7000, "Quad.easeInOut", true,0);
	
	this.background.inputEnabled = true;
	this.background.events.onInputDown.add(this.startGame, this);
	 
};

GameOver.prototype.startGame = function() {
	this.game.state.start("Level");
};


