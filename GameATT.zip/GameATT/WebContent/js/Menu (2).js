/**
 * Menu state.
 */
function Menu() {
	Phaser.State.call(this);
}

/** @type Phaser.State */
var proto = Object.create(Phaser.State);
Menu.prototype = proto;

Menu.prototype.preload = function() {
	this.load.pack("start", "assets/assets-pack.json");
};

Menu.prototype.create = function() {
	
	this.background = this.game.add.sprite(0,0,'menugame');
	this.background.height = 576;
	this.background.width = 1280;
	
	
	var cx=this.world.centerX;
	
	var box_start = this.add.sprite(cx,280,"box_start");
			box_start.height = 161;
			box_start.width = 253;
	var box_story = this.add.sprite(cx,280+115,"box_story");
			box_story.height = 191;
			box_story.width = 283;
	var box_contact = this.add.sprite(cx,280+120*2,"box_contact");
			box_contact.height = 191;
			box_contact.width = 283;

	box_start.anchor.set(0.5, 0.5);
	box_story.anchor.set(0.5, 0.5);
	box_contact.anchor.set(0.5, 0.5);
	
	box_start.inputEnabled = true;
	box_story.inputEnabled = true;
	box_contact.inputEnabled = true;
	
	box_start.events.onInputDown.add(this.startLevel, this);
	box_story.events.onInputDown.add(this.startStory, this);
	box_contact.events.onInputDown.add(this.startTeam, this);    
};
Menu.prototype.startLevel = function(){
	this.game.state.start("Level");
};
Menu.prototype.startStory = function(){
	this.game.state.start("Story");
};
Menu.prototype.startTeam = function(){
	this.game.state.start("Team");
};
