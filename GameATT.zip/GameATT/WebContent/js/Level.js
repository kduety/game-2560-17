/**
 * Level state.
 */
function Level() {
	Phaser.State.call(this);
}

/** @type Phaser.State */

//var game = new Phaser.Game(800, 600, Phaser.CANVAS, 'phaser-example', {create: this.create, update: this.update, render: render });


var proto = Object.create(Phaser.State);
Level.prototype = proto;



Level.prototype.create = function() {
	this.game.score = 0;
	this.game.life = 1;
	this.gameover=false;
	

	this.game.physics.startSystem(Phaser.Physics.ARCADE);
	this.game.physics.arcade.gravity.y = 1000;
	this.bg = this.game.add.sprite(0, 0, "bg1");
	this.bg.fixedToCamera = true;
	this.bg.width = this.game.width;
	this.bg.height = this.game.height;
	
		
	
	this.map = this.game.add.tilemap("lab7");
	this.map.addTilesetImage('tile_set');
	this.map_layer = this.map.createLayer("Tile Layer 1");
	this.map_layer2 = this.map.createLayer("Tile Layer 2");
	this.map_layer3 = this.map.createLayer("Tile Layer 3");	
	this.map_layer.resizeWorld();
	this.map_layer2.resizeWorld();
	this.map_layer3.resizeWorld();
	this.map.setCollisionBetween(0,9999,true,this.map_layer);
	this.map.setCollisionBetween(0,9999,true,this.map_layer2);
	this.map.setCollisionBetween(0,9999,true,this.map_layer3);
	
	this.scoreText = this.add.text(this.game.camera.width/2.5, 0, 'Score : '+this.game.score,{ font: '50px Arial',fill: 'red' });
	this.scoreText.fixedToCamera = true;
	
	//this.cat1 = this.addCat(200,100);
	//this.cat2 = this.addCat(400,100);
	this.game.time.events.add(Phaser.Timer.SECOND * 30, this.quitGame, this);
	// แสดง sprite
	this.enemies = this.add.group();
	for(x in this.map.objects.Object){
	var obj = this.map.objects.Object[x];
	if(obj.type == "player"){
	//console.log(this.player);
	this.player = this.addPlayer(obj.x,obj.y);
	this.game.camera.follow(this.player, Phaser.Camera.FOLLOW_PLATFORMER);
	this.player.play("idle");
	}else if(obj.type=="enemy1"){
		 var c = this.addTroll1(obj.x,obj.y);
		 this.enemies.add(c);
		 }else if(obj.type=="enemy2"){
			 var c = this.addTroll1(obj.x,obj.y);
			 this.enemies.add(c);
		 }
	
	}
	
	this.player.maxHealth = 1;
	this.player.setHealth(1);
	this.player.events.onKilled.addOnce(this.onPlayerKilled,this);
	this.player.canhit = true;
	
	this.lifeText = this.add.text(260, 0, 'Life: '+this.game.life, { fill: 'white' });
	this.lifeText.z = 10;
	this.lifeText.fixedToCamera = true;
	
	this.createWeapon();
	this.input.keyboard.addKeyCapture([Phaser.Keyboard.X]);
	 this.player.inputEnabled = true;
 	this.player.events.onInputDown.add(this.fireWeapon, this);
	
 /*	this.weapon2.bullets.body.allowGravity = false;
 	this.weapon1.bullets.body.allowGravity = false;*/
};


Level.prototype.fireWeapon2 = function() { 
	this.weapon2.fire();
	//this.weapon2.fire();
};

Level.prototype.fireWeapon = function() { 
	this.weapon1.fire();
	//this.weapon2.fire();
};

Level.prototype.createWeapon = function() {
	this.weapon1 = this.add.weapon(100,"bullet",1);
	this.weapon1.bulletKillType = Phaser.Weapon.KILL_WORLD_BOUNDS;
	this.weapon1.trackSprite(this.player,0,0,true);
	this.weapon1.bulletSpeed = 4000;
	this.weapon1.fireAngle = 180;
	this.weapon1.rate = 2000;
	
	this.weapon2 = this.add.weapon(100,"bullet",2);
	this.weapon2.bulletKillType = Phaser.Weapon.KILL_WORLD_BOUNDS;
	this.weapon2.trackSprite(this.player,0,0,true);
	this.weapon2.bulletSpeed = -4000;
	this.weapon2.fireAngle = -180;
	this.weapon2.rate = -2000;

};

Level.prototype.onCollide = function(enemies,bullet){
	enemies.kill();
	bullet.kill();
	
	this.game.score++;
	this.scoreText.text = 'Score : '+this.game.score;
	//this.addScoreText(enemies);
	//this.scoreText.text = 'Score: '+this.game.score;
	
	/*exp = this.add.sprite(alien.x, alien.y,"explosion");
	exp.anchor.set(0.5); 
	exp.animations.add("all",null,12,false).play().killOnComplete=true;
	this.boom.play();*/
	};


function kframes(key,n){
	f=[ ];
	for(var i=0;i<n;i++){
	f.push(key+i);
	console.log(key+i);
	}
	return f;
	}

function mframe(key,n){
	f=[ ];
	for(var i=0;i<n;i++){
	f.push(key+i);
	//console.log(key+i);
	}
	return f;
	}

Level.prototype.addPlayer = function(x,y) {
	
	var t = this.add.sprite(x,y,"k3");
	t.animations.add("idle", mframe("_IDLE_",7),12,true);
	t.animations.add("jump", mframe("_JUMP_",7),12,true);
	//t.animations.add("run", mframe("Run",8),12,true);
	t.animations.add("walk", mframe("_WALK_",7),12,true);
	t.animations.add("attack", mframe("ATTACK_",8),12,true);
	
	//t.anchor.set(0.5);
	t.anchor.set(0.8,0.7);
	t.scale.set(1.0);
	t.smoothed = false;
	t.play("idle");
	this.game.physics.arcade.enable(t);
	this.game.physics.enable(t);
	t.body.drag.setTo(500, 0);
	t.body.collideWorldBounds = true;
	
   //t.body.drag.set(70);
   //t.body.maxVelocity.set(200);
	return t;
	
	};
	
Level.prototype.update = function() {
	if(this.gameover) return;
		this.game.physics.arcade.collide(this.player,this.map_layer);
		this.game.physics.arcade.collide(this.enemies,this.map_layer);
		this.game.physics.arcade.overlap(this.player, this.enemies, this.collectCoin, null, this);
		this.game.debug.text("Time : " + this.game.time.events.duration/1000, 32, 32);

		this.game.physics.arcade.collide(this.player, this.enemies, this.hitEnemy,null,this);
		
		
		this.physics.arcade.collide(this.enemies,this.weapon1.bullets,this.onCollide,null,this);
		this.physics.arcade.collide(this.enemies,this.weapon2.bullets,this.onCollide,null,this);
		
		/*if(this.player.canhit){
			this.physics.arcade.collide(this.enemies,this.player,this.onPlayerCollide,null,this);
			}*/

		var p = 0;
		if (this.input.keyboard.isDown(Phaser.Keyboard.LEFT))
	    {
	    	 this.player.scale.x=-1.0;
			 this.player.body.velocity.x = -150;		 
		}
	    else if (this.input.keyboard.isDown(Phaser.Keyboard.RIGHT))
	    {
	    	 this.player.scale.x=1.0;
			 this.player.body.velocity.x = 150;		 
		}
	    else if (this.input.keyboard.isDown(Phaser.Keyboard.UP) && this.player.body.onFloor() )
	    {
	    	 this.player.body.velocity.y = -650;	 
		}
	    else if(this.input.keyboard.isDown(Phaser.Keyboard.SPACEBAR)){
			//this.player.play("attack");
	    	p = 1;
		}
		
	    
		if(this.player.body.onFloor())
		{
			if(this.player.body.velocity.x>0)
			{
				this.player.play("walk");
			}else if(this.player.body.velocity.x<0)
			{
				this.player.play("walk");
			}else if(p>0){
				
				if (this.player.scale.x>0){
					this.player.play("attack");
					this.fireWeapon();
			    	}else{
			    	this.player.play("attack");
			    	this.fireWeapon2();
			    	}
				
				//this.player.play("attack");	
				//this.fireWeapon();
			}
			else{
				this.player.play("idle");
			}
		}else
		{
			this.player.play("jump");
		}
		
	    if(this.input.keyboard.isDown(Phaser.Keyboard.UP) && this.player.body.onFloor())
	    {
	   	 	this.player.body.velocity.y = -650;
		}
	    
	    if(this.input.keyboard.isDown(Phaser.Keyboard.X)){
	    	if (this.player.scale.x>0){
			this.fireWeapon();
	    	}else{
	    		this.fireWeapon2();
	    	}
			//this.laser.play();
			}
	    
	    if(this.enemies.countLiving()==0 ){
			this.gameover=true;
			//delay.onComplete.addOnce(this.quitGame, this);
			this.game.state.start("Level");
			}
	    
	    
	    
};
	
Level.prototype.onPlayerKilled = function(){
	this.gameover=true;
	win = this.add.text(this.world.centerX,this.world.centerY,
	"คุณแพ้แล้ว",{ fill: 'Yellow'});
	win.anchor.set(0.5,0.5);
	win.scale.set(0.5);
	win.fixedToCamera = true;
	var tw = this.add.tween(win.scale);
	tw.to({x:2,y:2},1000, "Linear",true,0);
	delay = this.add.tween(win);
	delay.to({y:100},1000, "Linear",true,2000);
	tw.chain(delay);
	delay.onComplete.addOnce(this.quitGame, this);
	};


Level.prototype.onPlayerCollide = function(player,enemies){
	player.damage(1);
	//enemies.kill();
	this.game.life--;
	this.lifeText.text = 'Life: '+this.game.life;
	//this.scoreText.text = 'Score : '+this.game.score;
	player.canhit = true;
/*	player.alpha = 0.1;
	var tw = this.add.tween(player);
	tw.to({alpha:1},200, "Linear",true,0,50);
	tw.onComplete.addOnce(function(){this.alpha=1;this.canhit=true;}, player);*/
	return true;
	};

Level.prototype.addTroll1 = function(x, y) {
		c = this.add.sprite(x, y, "T1");
		c.animations.add("idle", mframe("Idle_",10),12, true);
		c.play("idle");
		c.anchor.set(0,0.9);
		this.game.physics.enable(c);
		c.body.collideWorldBounds = true;
		return c;
		};	

Level.prototype.quitGame = function() {
	//this.game.state.start("Preload");
	this.game.state.start("Menu");
};


Level.prototype.hitEnemy=function(player){
	//this.game.state.start("Level");
	
	player.canhit = true;
	player.damage(1);
	this.game.life--;
	this.lifeText.text = 'Life: '+this.game.life;
	player.kill();
	//enemies.kill();
	//this.game.life--;
//	this.lifeText.text = 'Life: '+this.game.life;
	
	//this.gameover=true;
	//delay.onComplete.addOnce(this.quitGame, this);
	//this.game.state.start("Level");
	
	
};
