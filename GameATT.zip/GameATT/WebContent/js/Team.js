/**
 * Story state.
 */
function Team() {
	Phaser.State.call(this);
}

/** @type Phaser.State */
var proto = Object.create(Phaser.State);
Team.prototype = proto;

Team.prototype.preload = function() {
	this.load.pack("start", "assets/assets-pack.json");
};

Team.prototype.create = function() {
	this.background = this.game.add.sprite(0,0,'contact');
	this.background.height = 576;
	this.background.width = 1200;
	
	var back = this.add.sprite(this.world.centerX, this.world.centerY,"back");
	back.width = 250 ;
	back.height = 200 ;
	back.anchor.set(-2, 0);
	
	var twn = this.add.tween(back);
	twn.to({ x : 500},0, "Quad.easeInOut", true, 0);
	
	back.inputEnabled = true;
	back.events.onInputDown.add(this.startGame, this);
	
	
};



Team.prototype.startGame = function() {
	this.game.state.start("Menu");
};