/**
 * Story state.
 */
function Story() {
	Phaser.State.call(this);
}

/** @type Phaser.State */


var proto = Object.create(Phaser.State);
Story.prototype = proto;

Story.prototype.preload = function() {
	this.load.pack("video", "assets/assets-pack.json");
};

Story.prototype.create = function() {
	
	var video = this.add.video("video");
			video.width = 1280;
			video.height = 800;
			
	var sprite = video.addToWorld(this.world.centerX, this.world.centerY, 0.5, 0.5, 0, 0);
	video.play(true);		
		
	
	 this.input.onDown.add(this.startGame,this);
	 //video.inputEnabled = true;
	//video.events.onInputDown.add(this.startGame, this);
	 
};


Story.prototype.startGame = function() {
	this.game.state.start("Level");
	
};