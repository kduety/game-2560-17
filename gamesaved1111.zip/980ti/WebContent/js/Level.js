/**
 * Level state.
 */
function Level() {
	Phaser.State.call(this);
}

/** @type Phaser.State */
var proto = Object.create(Phaser.State);
Level.prototype = proto;

Level.prototype.create = function() {
	this.game.physics.startSystem(Phaser.Physics.ARCADE);
	this.game.physics.arcade.gravity.y = 1000;
	this.bg = this.game.add.sprite(0, 0, "bg1");
	this.bg.fixedToCamera = true;
	this.bg.width = this.game.width;
	this.bg.height = this.game.height;
	
	
	this.map = this.game.add.tilemap("lab7");
	this.map.addTilesetImage('tile_set');
	this.map_layer = this.map.createLayer("Tile Layer 1");
	this.map_layer2 = this.map.createLayer("Tile Layer 2");
	this.map_layer3 = this.map.createLayer("Tile Layer 3");	
	this.map_layer.resizeWorld();
	this.map_layer2.resizeWorld();
	this.map_layer3.resizeWorld();
	this.map.setCollisionBetween(0,9999,true,this.map_layer);
	this.map.setCollisionBetween(0,9999,true,this.map_layer2);
	this.map.setCollisionBetween(0,9999,true,this.map_layer3);
	//this.cat1 = this.addCat(200,100);
	//this.cat2 = this.addCat(400,100);
	
	// แสดง sprite
	this.enemies = this.add.group();
	for(x in this.map.objects.Object){
	var obj = this.map.objects.Object[x];
	if(obj.type == "player"){
	//console.log(this.player);
	this.player = this.addPlayer(obj.x,obj.y);
	this.game.camera.follow(this.player, Phaser.Camera.FOLLOW_PLATFORMER);
	this.player.play("idle");
	}
	}
	
};

function gframes(key,n){
	var f=[ ];
	for(var i=0;i<=n;i++){
	var kf=key+"_"+(("00" + i).slice (-3));
	f.push(kf);
	}
	return f;
	}

function mframe(key,n){
	f=[ ];
	for(var i=1;i<n;i++){
	f.push(key+" ("+i+")");
	}
	return f;
	}

Level.prototype.addPlayer = function(x,y) {
	
	var t = this.add.sprite(x,y,"jack");
	t.animations.add("idle", mframe("Idle",10),12,true);
	t.animations.add("jump", mframe("Jump",10),12,true);
	t.animations.add("run", mframe("Run",8),12,true);
	t.animations.add("walk", mframe("Walk",10),12,true);
	t.anchor.set(0,0.9);
	t.smoothed = false;
	t.play("idle");
	this.game.physics.arcade.enable(t);
	//this.game.physics.enable(t);
	t.body.drag.setTo(500, 0);
	t.body.collideWorldBounds = true;
	return t;
	
	};
	
Level.prototype.update = function() {
		
		this.game.physics.arcade.collide(this.player,this.map_layer);
		this.game.physics.arcade.collide(this.enemies,this.map_layer);
		//this.game.physics.arcade.collide(this.player, this.enemies, this.hitEnemy,null,this);
		
		if (this.input.keyboard.isDown(Phaser.Keyboard.LEFT)) {
			this.player.body.velocity.x = -150;this.player.scale.x = -1;
			this.player.play("walk");
		} else if (this.input.keyboard.isDown(Phaser.Keyboard.RIGHT)) {
			this.player.body.velocity.x = 150;this.player.scale.x = 1;
			this.player.play("walk");
		}  
		
		if (this.input.keyboard.isDown(Phaser.Keyboard.UP)) {
			if(this.player.body.velocity.y==0)
			this.player.body.velocity.y = -1000;
		} else if (this.input.keyboard.isDown(Phaser.Keyboard.DOWN)) {
			//this.player.body.acceleration.y = 120;
		} else {
			//this.player.body.velocity.setTo(0, 0);
			//this.player.body.acceleration.setTo(0, 0);
			if(this.player.body.velocity.x==0) this.player.play("idle");
		}
		
	};

	
Level.prototype.quitGame = function() {
	this.game.state.start("Menu");
};